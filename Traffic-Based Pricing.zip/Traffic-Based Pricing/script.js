const Pageviews = document.getElementById("Pageviews");
const priceAmount = document.getElementById("priceAmount");
const trafficRange = document.getElementById("trafficRange");
const billingSwitch = document.getElementById("billingSwitch");

const pricingData = [
{ views: "10k", price: 8 },
{ views: "50k", price: 12 },
{ views: "100k", price: 16 },
{ views: "500k", price: 24 },
{ views: "1M", price: 36 }
];

function updatePrice(){
    const rangevalue = trafficRange.value - 1;
    const yearlyBilling = billingSwitch.checked;
    const price = pricingData[rangevalue].price;

    viewCount.textContent = pricingData[rangevalue].views;
    const finalPrice = yearlyBilling ? (price * 0.75).toFixed(2) : price.toFixed(2);
    priceAmount.textContent = finalPrice;
}

trafficRange.addEventListener("input", updatePrice);
billingSwitch.addEventListener("change", updatePrice);

updatePrice();